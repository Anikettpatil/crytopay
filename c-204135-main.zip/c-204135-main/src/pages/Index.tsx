
import { useState, useEffect } from "react";
import MarketStats from "@/components/MarketStats";
import CryptoChart from "@/components/CryptoChart";
import PortfolioCard from "@/components/PortfolioCard";
import CryptoList from "@/components/CryptoList";
import Exchange from "@/components/Exchange";
import Navbar from "@/components/Navbar";

const Index = () => {
  const [currentView, setCurrentView] = useState("dashboard");
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const loggedIn = localStorage.getItem("isLoggedIn") === "true";
    setIsLoggedIn(loggedIn);
  }, []);

  const handleNavigate = (target: string) => {
    console.log(`Navigating to: ${target}`);
    
    switch (target) {
      case "home":
        setCurrentView("dashboard");
        break;
      case "exchange":
        setCurrentView("exchange");
        break;
      case "market":
        setCurrentView("dashboard");
        // Scroll to market section if needed
        break;
      case "scanner":
        // Future QR scanner implementation
        console.log("QR Scanner not implemented yet");
        break;
      default:
        setCurrentView("dashboard");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    setIsLoggedIn(false);
    setCurrentView("dashboard");
  };

  if (currentView === "exchange") {
    return (
      <div className="min-h-screen bg-background">
        <div className="gradient-bg-welcome">
          <Navbar onLogout={handleLogout} onNavigate={handleNavigate} />
        </div>
        <Exchange />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="gradient-bg-welcome">
        <Navbar onLogout={handleLogout} onNavigate={handleNavigate} />
      </div>
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <header className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Crypto Dashboard</h1>
            <p className="text-muted-foreground">Welcome back to your portfolio</p>
          </header>
          
          <MarketStats />
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <CryptoChart />
            </div>
            <div>
              <PortfolioCard />
            </div>
          </div>
          
          <CryptoList />
        </div>
      </div>
    </div>
  );
};

export default Index;
