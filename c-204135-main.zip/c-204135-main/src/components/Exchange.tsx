
import { useState } from "react";
import { ArrowUpIcon, ArrowDownIcon, TrendingUpIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

const fetchExchangeData = async () => {
  const response = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false');
  if (!response.ok) {
    throw new Error('Network response was not ok');
  }
  return response.json();
};

const Exchange = () => {
  const [selectedCrypto, setSelectedCrypto] = useState(null);
  const [amount, setAmount] = useState("");
  const [orderType, setOrderType] = useState("buy");

  const { data: cryptos, isLoading } = useQuery({
    queryKey: ['exchange-cryptos'],
    queryFn: fetchExchangeData,
    refetchInterval: 30000,
  });

  const handleTrade = () => {
    if (!selectedCrypto || !amount) {
      alert("Please select a cryptocurrency and enter an amount");
      return;
    }
    
    console.log(`${orderType.toUpperCase()} order: ${amount} ${selectedCrypto.symbol.toUpperCase()} at $${selectedCrypto.current_price}`);
    alert(`${orderType.toUpperCase()} order placed for ${amount} ${selectedCrypto.symbol.toUpperCase()}`);
    
    // Reset form
    setAmount("");
    setSelectedCrypto(null);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="max-w-7xl mx-auto">
          <div className="glass-card p-6 rounded-lg animate-fade-in">
            <h2 className="text-2xl font-bold mb-6">Exchange</h2>
            <div className="flex items-center justify-center h-64">
              <span className="text-muted-foreground">Loading exchange data...</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Crypto Exchange</h1>
          <p className="text-muted-foreground">Trade cryptocurrencies with live market prices</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Trading Panel */}
          <div className="glass-card p-6 rounded-lg animate-fade-in">
            <h2 className="text-xl font-semibold mb-6">Place Order</h2>
            
            {/* Order Type Toggle */}
            <div className="flex mb-6">
              <Button
                variant={orderType === "buy" ? "default" : "outline"}
                onClick={() => setOrderType("buy")}
                className="mr-2"
              >
                Buy
              </Button>
              <Button
                variant={orderType === "sell" ? "default" : "outline"}
                onClick={() => setOrderType("sell")}
              >
                Sell
              </Button>
            </div>

            {/* Selected Crypto Display */}
            {selectedCrypto && (
              <div className="mb-6 p-4 border border-secondary rounded-lg">
                <div className="flex items-center gap-3">
                  <img src={selectedCrypto.image} alt={selectedCrypto.name} className="w-8 h-8" />
                  <div>
                    <p className="font-medium">{selectedCrypto.name}</p>
                    <p className="text-sm text-muted-foreground">${selectedCrypto.current_price.toLocaleString()}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Amount Input */}
            <div className="mb-6">
              <label className="block text-sm font-medium mb-2">Amount</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="Enter amount"
                className="w-full p-3 bg-secondary border border-muted rounded-lg text-foreground"
              />
            </div>

            {/* Trade Button */}
            <Button
              onClick={handleTrade}
              className="w-full"
              disabled={!selectedCrypto || !amount}
            >
              {orderType === "buy" ? "Buy" : "Sell"} {selectedCrypto?.symbol?.toUpperCase() || "Crypto"}
            </Button>
          </div>

          {/* Market Data */}
          <div className="glass-card p-6 rounded-lg animate-fade-in">
            <h2 className="text-xl font-semibold mb-6">Select Cryptocurrency</h2>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {cryptos?.map((crypto) => (
                <div
                  key={crypto.id}
                  onClick={() => setSelectedCrypto(crypto)}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    selectedCrypto?.id === crypto.id
                      ? "border-primary bg-primary bg-opacity-10"
                      : "border-secondary hover:border-muted"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <img src={crypto.image} alt={crypto.name} className="w-8 h-8" />
                      <div>
                        <p className="font-medium">{crypto.name}</p>
                        <p className="text-sm text-muted-foreground">{crypto.symbol.toUpperCase()}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">${crypto.current_price.toLocaleString()}</p>
                      <span
                        className={`flex items-center gap-1 text-sm ${
                          crypto.price_change_percentage_24h >= 0 ? "text-success" : "text-warning"
                        }`}
                      >
                        {crypto.price_change_percentage_24h >= 0 ? (
                          <ArrowUpIcon className="w-3 h-3" />
                        ) : (
                          <ArrowDownIcon className="w-3 h-3" />
                        )}
                        {Math.abs(crypto.price_change_percentage_24h).toFixed(2)}%
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Market Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8 animate-fade-in">
          <div className="glass-card p-6 rounded-lg">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-muted-foreground">24h Trading Volume</h3>
              <TrendingUpIcon className="w-4 h-4 text-success" />
            </div>
            <p className="text-2xl font-semibold mt-2">$156.8B</p>
            <span className="text-sm text-success flex items-center gap-1">
              <ArrowUpIcon className="w-3 h-3" />
              8.2%
            </span>
          </div>
          
          <div className="glass-card p-6 rounded-lg">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-muted-foreground">Active Pairs</h3>
              <TrendingUpIcon className="w-4 h-4 text-success" />
            </div>
            <p className="text-2xl font-semibold mt-2">47</p>
            <span className="text-sm text-success flex items-center gap-1">
              <ArrowUpIcon className="w-3 h-3" />
              Available
            </span>
          </div>
          
          <div className="glass-card p-6 rounded-lg">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-muted-foreground">Spread</h3>
              <TrendingUpIcon className="w-4 h-4 text-success" />
            </div>
            <p className="text-2xl font-semibold mt-2">0.1%</p>
            <span className="text-sm text-success flex items-center gap-1">
              Low fees
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Exchange;
