
import React, { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

const NavBarItem = ({ title, classprops, onClick }: { title: string; classprops?: string; onClick?: () => void }) => (
  <li
    className={`mx-4 cursor-pointer ${classprops}`}
    onClick={onClick}
    role="menuitem"
    tabIndex={0}
    onKeyPress={(e) => {
      if (e.key === "Enter" && onClick) onClick();
    }}
  >
    {title}
  </li>
);

const Navbar = ({ onLogout, onNavigate }: { onLogout?: () => void; onNavigate?: (target: string) => void }) => {
  const [toggleMenu, setToggleMenu] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const status = localStorage.getItem("isLoggedIn");
    setIsLoggedIn(status === "true");
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    setIsLoggedIn(false);
    setToggleMenu(false);
    if (onLogout) onLogout();
  };

  const handleLogin = () => {
    window.location.href = "/";
  };

  const handleNavigate = (target: string) => {
    setToggleMenu(false);
    if (onNavigate && ["home", "scanner", "market", "exchange"].includes(target)) {
      onNavigate(target);
    } else if (target === "home") {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  return (
    <nav className="w-full flex md:justify-center justify-between items-center p-4">
      <div className="md:flex-[0.5] flex-initial justify-center items-center">
        <div
          className="text-white font-bold text-2xl cursor-pointer"
          onClick={() => handleNavigate("home")}
        >
          CryptoHub
        </div>
      </div>

      {/* Desktop Menu */}
      <ul className="text-white md:flex hidden list-none flex-row justify-between items-center flex-initial">
        <NavBarItem title="Home" onClick={() => handleNavigate("home")} />
        <NavBarItem title="Market" onClick={() => handleNavigate("market")} />
        <NavBarItem title="Exchange" onClick={() => handleNavigate("exchange")} />
        <NavBarItem title="QR Scanner" onClick={() => handleNavigate("scanner")} />
        <NavBarItem title="Wallets" />

        <li
          className={`py-2 px-7 mx-4 rounded-full cursor-pointer ${
            isLoggedIn ? "bg-red-600 hover:bg-red-800" : "bg-[#2952e3] hover:bg-[#2546bd]"
          }`}
          onClick={isLoggedIn ? handleLogout : handleLogin}
        >
          {isLoggedIn ? "Logout" : "Login"}
        </li>
      </ul>

      {/* Mobile Menu Icon */}
      <div className="flex relative">
        {!toggleMenu ? (
          <Menu
            size={28}
            className="text-white md:hidden cursor-pointer"
            onClick={() => setToggleMenu(true)}
          />
        ) : (
          <X
            size={28}
            className="text-white md:hidden cursor-pointer"
            onClick={() => setToggleMenu(false)}
          />
        )}

        {/* Mobile Menu */}
        {toggleMenu && (
          <ul className="z-10 fixed top-0 right-0 p-3 w-[70vw] h-screen shadow-2xl md:hidden list-none flex flex-col justify-start items-end rounded-md blue-glassmorphism text-white animate-slide-in bg-[#0f0f0f]">
            <li className="text-xl w-full my-2">
              <X onClick={() => setToggleMenu(false)} />
            </li>

            <NavBarItem
              title="Home"
              classprops="my-2 text-lg"
              onClick={() => handleNavigate("home")}
            />
            <NavBarItem
              title="Market"
              classprops="my-2 text-lg"
              onClick={() => handleNavigate("market")}
            />
            <NavBarItem
              title="Exchange"
              classprops="my-2 text-lg"
              onClick={() => handleNavigate("exchange")}
            />
            <NavBarItem
              title="QR Scanner"
              classprops="my-2 text-lg"
              onClick={() => handleNavigate("scanner")}
            />
            <NavBarItem title="Wallets" classprops="my-2 text-lg" />

            <li
              className={`py-2 px-7 mt-4 rounded-full cursor-pointer ${
                isLoggedIn ? "bg-red-600 hover:bg-red-800" : "bg-[#2952e3] hover:bg-[#2546bd]"
              }`}
              onClick={() => {
                setToggleMenu(false);
                isLoggedIn ? handleLogout() : handleLogin();
              }}
            >
              {isLoggedIn ? "Logout" : "Login"}
            </li>
          </ul>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
